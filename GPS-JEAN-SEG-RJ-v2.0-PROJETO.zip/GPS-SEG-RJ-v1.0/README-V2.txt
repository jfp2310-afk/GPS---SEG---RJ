GPS JEAN SEG RJ v2.0
- Interface reformulada.
- Foreground Service para monitoramento de localização.
- Alertas: 2 km, 500 m, 200 m e 100 m; crítico de 5 s.
- Estrutura de base local em app/src/main/assets/risk_zones.json.
- O arquivo de zonas vem vazio de propósito: não foram inventadas coordenadas nem copiadas bases privadas sem licença.
- Fontes de referência verificadas: GENI/UFF + Fogo Cruzado (Mapa Histórico dos Grupos Armados, 2025/dados 2024); Fogo Cruzado API/dados abertos; ISP-RJ bases cartográficas 2026; Dados de Riscos (referência pública, 1671 áreas, jul/2026).
- O Google Maps é aberto para navegação. A URL pública do Maps não oferece API para evitar polígonos criminais personalizados. Uma rota que realmente desvie de polígonos exige motor de roteamento próprio/SDK com custos por aresta ou waypoints calculados.
- Não foi ativado "avoid=tolls": a rota normal pode utilizar vias pedagiadas legalmente, sem induzir desvios para burlar praças de pedágio.
