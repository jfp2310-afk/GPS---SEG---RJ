package br.com.jeanpereira.gpssegrj;
public class RiskZone { public final String name,group,source,date; public final double lat,lon,radius;
 public RiskZone(String n,String g,double a,double o,double r,String s,String d){name=n;group=g;lat=a;lon=o;radius=r;source=s;date=d;}
}
