package br.com.jeanpereira.gpssegrj;
import android.content.*;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
public class RiskRepository{
 public static List<RiskZone> load(Context c){List<RiskZone> out=new ArrayList<>();try(InputStream in=c.getAssets().open("risk_zones.json")){String s=new String(in.readAllBytes(),StandardCharsets.UTF_8);JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new RiskZone(o.getString("name"),o.getString("group"),o.getDouble("lat"),o.getDouble("lon"),o.optDouble("radius_m",250),o.optString("source",""),o.optString("date","")));}}catch(Exception ignored){}return out;}
}
