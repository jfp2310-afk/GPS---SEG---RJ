GPS SEG RJ v1.0 — PROJETO ANDROID

Aplicativo Android: br.com.jeanpereira.gpssegrj
SDK mínimo: Android 8.0 (API 26)
Target/Compile SDK: 35
Java: 17
Android Gradle Plugin: 8.7.3
Gradle recomendado: 8.9

COMPILAÇÃO
1. Abra a pasta raiz no Android Studio atual.
2. Aguarde a sincronização do Gradle e instalação do Android SDK 35, se solicitada.
3. Menu Build > Build APK(s).
4. APK de debug: app/build/outputs/apk/debug/app-debug.apk

GITHUB ACTIONS
O arquivo .github/workflows/build-apk.yml compila com Java 17 e Gradle 8.9 e publica o APK como artifact GPS-SEG-RJ-v1.0.

Observação: o projeto não contém binários do Gradle Wrapper. O workflow usa setup-gradle e não depende do wrapper.
